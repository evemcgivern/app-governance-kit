# Platform guide: AI system intake and risk tiering

Where an AI inventory and AI risk assessments live in ServiceNow, and how Flexera One can surface AI software and SaaS usage. Where no source names a module, table, or field, this guide leaves a gap and says so.

## ServiceNow: AI governance and Integrated Risk Management (IRM)

ServiceNow's risk and compliance work sits in **Integrated Risk Management (IRM)**, its platform for unifying governance, risk, and compliance processes. On top of that, ServiceNow has named a governance layer for AI: **AI Control Tower** (also called the "AI Inventory and Control Tower," AICT, in a ServiceNow-employee community post). ServiceNow's community documentation describes it as the place that holds the policies, roles, and approvals AI use cases pass through. That flow is the closest confirmed analog to this method's intake-to-inventory steps:

- A use case is registered, which matches this method's restatement and inventory record.
- It's classified and assessed, which matches the tiering.
- It's approved, which matches the approval decision.
- It's then monitored, which matches the re-review date.

ServiceNow's community writeup maps AI Control Tower's stages onto the four NIST AI RMF functions this method also cites:

- Intake and stakeholder mapping across domains such as IT, HR, Finance, and Security: **Map**.
- Assessment workflows and evidence collection: **Measure**.
- Centralizing policy, roles, and approvals: **Govern**.
- Linking identified risks to owners and remediation workflows in a closed loop: **Manage**.

AI Control Tower has a documented three-layer data model. The table names below come from ServiceNow Community posts, not an official field-level reference:

- **AI Product Model**: the catalog-level record for what type of AI something is. Agent/skill class hierarchy: `cmdb_model` → `cmdb_sw_component_product_model` → `cmdb_ai_system_component_product_model`; a parallel branch covers models, datasets, prompts, and MCP servers (`cmdb_ai_model_product_model`, `cmdb_ai_dataset_product_model`, `cmdb_ai_prompt_product_model`, `cmdb_mcp_product_model`).
- **AI Digital Asset**: the ownership-and-lifecycle-management record created at intake, and the closest confirmed analog to this method's inventory record. For an AI system or use case, the table is **`alm_ai_system_digital_asset`** (siblings: `alm_ai_model_digital_asset`, `alm_ai_prompt_digital_asset`, `alm_ai_dataset_digital_asset`, `alm_mcp_digital_asset`).
- **Risk tier / governance attributes**: carried on the related table **`sn_ai_governance_asset_governance_details`**, anchored to the Digital Asset. No field (column) name inside that table is confirmed; only the table name.
- **Required controls**: no named field or table is confirmed; governance-detail and risk records are described only as generically linked to the Digital Asset, implying GRC control-objective records rather than a named field.
- **AI Configuration Item (CI)**: the deployment record: `cmdb_ci_function_ai`, `cmdb_ci_appl_ai_application`, `cmdb_ci_function_mcp`, `cmdb_ci_ai_model_deployment`, linked to assets via `cmdb_rel_asset_ci`.
- **Intake record/form**: the **"AI Use Case Intake Form,"** submitted via Employee Center → Technology Services → AI Assets (or the AICT Workspace, or REST API `POST /sn_ent/asset/ai_system`). Submitting it auto-creates the Digital Asset (and the Product Model, if new).
- **Business Application link**: `sn_apm_ws_ba_product_model_map`, attaching an AI capability to a Business Application at intake.

Separately, ServiceNow's own official documentation names **UI-level** objects in AI Control Tower's home page: an "AI asset inventory" tab, and a "Risk and compliance" tab that classifies AI systems, models, and datasets into High, Medium, Low, and Unacceptable risk categories, tracked against the NIST AI RMF and the EU AI Act.

Within IRM, AI-specific assessment work is handled by **ServiceNow Otto for IRM** (the current name for what earlier release material called "Now Assist for IRM," confirmed on a live docs page). Its documentation names two AI agents. A **"Report a GRC issue" AI agent** walks a user through reporting a governance, risk, or compliance issue and suggests relevant controls, entities, and policies before submission. A **Control Objective Change Agent** lets a user review and update impacted control objectives against the latest citation details. Neither is an AI-intake-specific form.

Treat AI Control Tower as the product surface this method's steps would run inside. Treat IRM's assessment and risk-register capabilities as the mechanism for this method's control list and risk-register entry.

ServiceNow's IRM product page (`servicenow.com/products/integrated-risk-management.html`) and AI Control Tower product page (`servicenow.com/products/ai-control-tower.html`) return connection errors, so both are cited from Wayback Machine snapshots (September 2026). The AI Control Tower solution-brief PDF could not be retrieved, and the Wayback Machine has no copy. ServiceNow's press release on the same capabilities (Discover, Observe, Govern, Secure, Measure), issued through its investor-relations newswire, stands in for it.

## Flexera One: surfacing AI software and SaaS usage

Flexera merged its own and Snow's SaaS management products into a single **Flexera One SaaS Management** offering, which Flexera's press material frames around **shadow AI**: unsanctioned or unlicensed AI tools in use without governance visibility. Discovery runs through what Flexera's press release calls a **Comprehensive Discovery Engine**. It combines Browser and Financial Discovery, an installed Agent, API connectors, CASB integration, and SSO connections. That's the multi-source approach Flexera documents for general SaaS and hybrid IT discovery, extended to flag AI applications and employee AI tool usage alongside ordinary SaaS.

Flexera's SaaS Management page describes helping an organization take control of AI usage: discover where AI is used, assess risk and cost, and check usage against company policy. That's the discovery-and-risk-flagging step this method's supplier-and-provider identification step (checklist item 6) would draw on before intake proceeds.

Flexera's current (2026) product line also provides AI discovery, spend tracking, and usage-policy-alignment features through Flexera One AI Cost Management (covering AI Apps & Agents, AI Models & Tokenomics, AI Data Cloud Management, AI Compute Management), SaaS Management, and Technopedia. Its AI Cost Management plan-comparison table lists a generic feature row, "Policy and governance," described as enforcing guardrails, approvals, and compliance. That is a feature category. A generic, non-AI-specific approval-workflow engine exists separately in Flexera One's Commander module (for IT service and change requests); nothing in Flexera's documentation or marketing names an AI-specific use of it for AI intake.

No Flexera product names a table, field, or record for an AI intake decision, an approval, or a risk-tier classification. Flexera's public-sector guidance describes intake and risk-review as processes an organization builds itself. This method's inventory record ([`template.md`](template.md)) has no confirmed Flexera equivalent.

## Acquisition gate and approved-tools register

No source checked names a field for the acquisition gate result or an approved-AI-tools register in either product. Run the gate with `sam-toolkit/acquisition-gate-checklist.md` and keep the register as a filtered view of the AI inventory.

## What remains unconfirmed

- The specific field/column name that stores risk tier inside `sn_ai_governance_asset_governance_details` (only the table name is confirmed), and any named field for "required controls."
- Whether the ServiceNow-Community-sourced table names above match what an official field-level ServiceNow reference page would list; no such official schema-level page could be reached (the official docs are JS-rendered and gave only UI-level tab descriptions).
- The content of the AI Control Tower solution-brief PDF (unreachable, with no archived copy found).

## Sources checked

- [Managing AI Risk Using NIST AI RMF and ServiceNow AI Control Tower, ServiceNow Community](https://www.servicenow.com/community/now-assist-articles/managing-ai-risk-using-nist-ai-rmf-and-servicenow-ai-control/ta-p/3466409): AI Control Tower, the register/classify/assess/approve/monitor flow, and its mapping to NIST AI RMF's Govern/Map/Measure/Manage.
- [Understanding the AI Inventory Data Model in ServiceNow, ServiceNow Community](https://www.servicenow.com/community/cmdb-blog/understanding-the-ai-inventory-data-model-in-servicenow-product/ba-p/3546771): table names read from the page HTML; AI Product Model, AI Digital Asset (`alm_ai_system_digital_asset`), `sn_ai_governance_asset_governance_details`, AI Configuration Item tables.
- [AI Inventory Data Model in ServiceNow, how can we utilize in EA, ServiceNow Community](https://www.servicenow.com/community/itom-forum/ai-inventory-data-model-in-servicenow-how-can-we-utilised-in/td-p/3572768): table names read from the page HTML; confirms "AI Use Case Intake Form" and that the Digital Asset carries steward and risk-tier data.
- [AI agents in Now Assist for IRM, ServiceNow Docs](https://www.servicenow.com/docs/r/governance-risk-compliance/grc-common-functions/standalone-ai-agents-in-risk-sustainability.html): confirms the current name ServiceNow Otto for IRM, and the "Report a GRC issue" and Control Objective Change agents.
- [Risk and compliance tab in AI Control Tower, ServiceNow Docs](https://www.servicenow.com/docs/r/intelligent-experiences/ai-control-tower/risk-compliance-tab-aict.html): the Risk and compliance tab and its High/Medium/Low/Unacceptable classification.
- [AI Control Tower Home page, ServiceNow Docs](https://www.servicenow.com/docs/r/intelligent-experiences/ai-control-tower/ai-control-tower-home-page.html): the "AI asset inventory" and "Risk and compliance" tabs.
- [Integrated Risk Management (IRM) product page, ServiceNow, Wayback Machine snapshot (2026-09-03)](http://web.archive.org/web/20260903003523/https://www.servicenow.com/products/integrated-risk-management.html): product positioning; no AI-specific content in the page body.
- [AI Control Tower product page, ServiceNow, Wayback Machine snapshot (2026-09-20)](http://web.archive.org/web/20260920152352/https://www.servicenow.com/products/ai-control-tower.html): the five capability pillars (Discover, Observe, Govern, Secure, Measure) and the auto-discovery/unified-inventory FAQ line.
- [ServiceNow expands AI Control Tower, ServiceNow press release, investor-relations CDN](https://s205.q4cdn.com/537566246/files/doc_news/ServiceNow-expands-AI-Control-Tower-to-discover-observe-govern-secure-and-measure-AI-deployed-across-any-system-in-the-enterprise-2026.pdf): the same five pillars and five NIST/EU-AI-Act-aligned risk frameworks, in ServiceNow's own words.
- [Flexera One AI Cost Management](https://www.flexera.com/products/ai-cost-management): the AI Apps & Agents / AI Models & Tokenomics / AI Data Cloud Management / AI Compute Management areas and the generic "Policy and governance" plan row.
- [Flexera One SaaS Management](https://www.flexera.com/products/flexera-one/saas-management): AI usage discovery and policy-alignment framing.
- [Flexera Launches New Unified SaaS Management Solution to Improve Visibility for Shadow AI, Flexera press release](https://www.flexera.com/about-us/press-center/flexera-launches-new-saas-management-solution): the merged Flexera One SaaS Management product and its Comprehensive Discovery Engine.
- [5 AI best practices for public sector organizations, Flexera blog](https://www.flexera.com/blog/ai/public-sector-ai-governance-visibility/): intake, risk-review, and inventory discipline framed as agency-built practice, not a Flexera feature.
