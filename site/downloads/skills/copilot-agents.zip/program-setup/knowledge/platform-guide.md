# Platform guide: Stand up a governance program

Where this method's intake, approval, and meeting-input steps map onto ServiceNow and Flexera One. Where no source names a module, table, or field, the guide says so.

## ServiceNow: intake through a catalog item, decisions through an approval workflow

A governance intake form (this method's step 5) maps onto a **Service Catalog** item: a catalog item carries a request form and a **Workflow** field that defines its fulfilment process, including any approval step. Submitting the item creates a **Request** (table `sc_request`), which in turn creates one or more **Requested Items** (`sc_req_item`, referencing the originating **Catalog Item** on `sc_cat_item`); the request-level approval covers everything in the cart, and once that clears, each requested item's own fulfilment work is tracked as **Catalog Tasks** (`sc_task`).

Approval logic is built either in the classic **Workflow Editor** or in **Flow Designer**. Both use activities such as **Approval - User**, **Approval - Group**, or **Approval - Action**, evaluated against a **Condition**. That is the mechanism a cost or risk threshold (this method's step 3) would be built on, for example routing to the council only when a requested item's cost exceeds a set figure.

Approval records live on table **`sysapproval_approver`**, confirmed by multiple ServiceNow Community and Support sources, and move through states such as Requested, Approved, Rejected, and Canceled. That is the natural place to attach this method's decision log, alongside workflow activity logs and notifications for each decision. A council's decision log therefore maps onto ServiceNow's own Service Catalog tables end to end: `sc_request` → `sc_req_item` (from `sc_cat_item`) → `sc_task`, with approvals on `sysapproval_approver`. ServiceNow documentation on the exact field-level distinction within the approval table (for example, between an "Approving" and an "Approval for" field) could not be loaded. The table name itself is confirmed by multiple sources.

ServiceNow's Service Catalog Management documentation under `docs.servicenow.com` and its product page (`servicenow.com/products/service-catalog-management.html`) wouldn't load. The docs pages redirect to a generic landing page (tried across the current, Sandiego, and Quebec bundle URL forms), and the product page returns a 403. The Workflow / Flow Designer / Approval - User / Approval - Group / RITM / Request terminology above comes from a ServiceNow Community how-to thread.

## Flexera One: usage, spend, and shadow IT discovery as meeting inputs

Flexera One's SaaS Management product combines **application usage, license data, and spend insights** to surface waste, and its discovery draws on multiple sources at once. Flexera names financial and expense data, API connectors, a browser extension, and connections to single sign-on (SSO) and Cloud Access Security Broker (CASB) systems. Together they build a fuller picture than any one source alone, including applications nobody sanctioned. Flexera positions that combined view of usage, spend, and contract data as the basis for governance and license-optimization decisions. It could feed this method's cadence step, so the body convenes with a live item to decide on.

No confirmed Flexera One field, table, or dashboard name exists for a per-application "last reviewed" or "last decided" date that this method's decision log could cite directly; Flexera's documented capability is usage-and-spend-based discovery and optimization recommendations; it names no governance-decision object. The claims above come from Flexera's product and solution marketing pages.

## Sources checked

- [Understanding Approval Workflows in ServiceNow: A Practical Guide, ServiceNow Community](https://www.servicenow.com/community/servicenow-ai-platform-forum/understanding-approval-workflows-in-servicenow-a-practical-guide/td-p/3129602): Flow Designer, Workflow Editor, Approval - User/Group/Action activities, condition-based triggers, RITM/Request objects, approval states, and workflow activity logs.
- [Service Catalog: important tables for REQ, RITM, SCTASK, ServiceNow Community](https://www.servicenow.com/community/developer-forum/service-catalog-important-tables-for-req-ritm-sctask-catagory/m-p/2115312): confirms `sc_request`, `sc_req_item`, and `sc_task` table names.
- [Populating field from Catalog Item (sc_cat_item) to produced RITM record (sc_req_item), Now Support KB](https://support.servicenow.com/kb?id=kb_article_view&sysparm_article=KB0813783): confirms the `sc_cat_item` table name.
- [Optimize SaaS spend and utilization with Flexera One SaaS Management, Flexera](https://www.flexera.com/products/flexera-one/saas-management): combined usage, license, and spend insights; multi-source discovery (financial data, API connectors, browser extension, SSO/CASB); license right-sizing and unused-application elimination.
- [Mitigate Risks with Shadow IT Discovery and Management, Flexera](https://www.flexera.com/solutions/saas-spend/shadow-it): shadow IT discovery methods (usage metering, CASB, browser extension, financial records, SSO) and the case for combining multiple sources over relying on one.

Pages that did not return readable content to an automated fetch: ServiceNow's Service Catalog Management documentation under `docs.servicenow.com` (redirects to a generic docs landing page across three release-bundle URL forms tried) and its Service Catalog Management product page (`servicenow.com/products/service-catalog-management.html`, 403). A Now Support KB and a third-party integration doc describing the approval table's field-level distinctions also returned only page chrome, no article body, on every attempt. Nothing above rests on them.
